为了实现在docker里自动部署apache2和php5改写了脚本使其能自动安装。
自动安装软件配置如下：
1.apache-2.4.29
2.php5.5.38
3.安装php_mysql模块    #原脚本选择不安装mysql时默认不装mysql模块。
4.memcached-2.2.0     #原脚本memcached-3.0.3不能用在php5。
自动安装命令：
./lamp.sh auto

其它帮助请查看官方reanme.md或者官网https://lamp.sh