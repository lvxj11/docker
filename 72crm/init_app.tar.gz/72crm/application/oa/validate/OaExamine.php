<?php

namespace app\oa\validate;
use think\Validate;
/**
* 设置模型
*/
class OaExamine extends Validate{

	protected $rule = [
	];
	protected $message = [				
	];
	protected $scene = [
        'edit'  =>  [],
    ];
}