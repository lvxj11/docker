<?php
return [
    'CUSTOMER' => '客户', 
];