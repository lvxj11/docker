<?php
return [
     'hello thinkphp'  => 'hello thinkphp',
     'data type error' => 'data type error',
];