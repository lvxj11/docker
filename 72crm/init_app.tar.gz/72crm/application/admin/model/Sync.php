<?php
// +----------------------------------------------------------------------
// | Description: 同步
// +----------------------------------------------------------------------
// | Author:  Michael_xu | gengxiaoxu@5kcrm.com
// +----------------------------------------------------------------------

namespace app\admin\model;

use app\admin\model\Common;

class Sync extends Common 
{
	public function syncData($param)
	{
		return true;
	}	
}