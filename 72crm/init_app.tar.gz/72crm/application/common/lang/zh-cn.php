<?php
return [
    'ACTIONLOG' => '%s%s在%s%s了id为%d的%s',
    'MEMBER' => '用户',
    'CUSTOMER' => '客户',
    'EXAMINE' => '审批',

    'SAVE' => '创建',
    'UPDATE' => '修改',
    'DELETE' => '删除',
    'CHECK' => '审核',
    'REVOKECHECK' => '撤销审核',
    'SAVE SUCCESS' => '创建成功',
    'SAVE FAILED' => '创建失败',
	'UPDATE SUCCESS' => '修改成功',
    'UPDATE FAILED' => '修改失败',    
	'DELETE SUCCESS' => '删除成功',
    'DELETE FAILED' => '删除失败',
    'HAVE NOT PRIVILEGES' => '您没有权限！',
    'RECORD_NOT_EXIST_OR_HAVE_BEEN_DELETED'=>'%s不存在或已被删除！', 
];