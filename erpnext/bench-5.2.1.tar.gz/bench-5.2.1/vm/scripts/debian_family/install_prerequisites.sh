#!/bin/bash -eux

# Install base requirements.
apt-get install -y curl git wget vim python-dev gcc
